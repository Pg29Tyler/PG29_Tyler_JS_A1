changes i made:

- included jquery and jquery ui on the frontend
- added the "#add-block" button
- added the .block style
- added missing parentheses on app.js line 1
- moved the parenthesis on app.js line 56 to 58
- commented out all the setStatus function calls
- commented out all the loadLevelList function calls
- added leading slashes to server.js line 47 and 106

updated changes I made:) :
- added new buttons for the player to use to spawn new objects
- added new objects for the player to spawn in
- updated the collecting system so it can collect and save the new objects